#import "pystructs.h"

bt_ProxyObject *bt_getProxy(NSPort *receivePort, NSPort *sendPort, PyObject *chooseFileFlag);
bt_ProxyObject *bt_getMetaProxy(NSPort *receivePort, NSPort *sendPort);
